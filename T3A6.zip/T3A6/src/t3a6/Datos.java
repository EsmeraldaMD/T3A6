
package t3a6;
import java.util.Scanner;
/**
 *
 * @author esmer
 */
public class Datos {
    
    public void datos(){
    Scanner obj=new Scanner(System.in);
    Calculo ob=new Calculo();
        System.out.println("NOMINAS\n\nIngrese el numero de empleados");
        int m=obj.nextInt();
        int i=1;
        for(i=i; i<=m;i++){
            System.out.print("Ingrese su nombre: ");
            String nombre=obj.next();
            System.out.print("Ingrese sus apellidos: ");
            String apellidos=obj.next();
            System.out.print("Ingerse su RFC: ");
            String rfc=obj.next();
            System.out.print("Ingrese su CURP: ");
            String curp=obj.next();
            System.out.print("Ingrese su Email: ");
            String email=obj.next();
            System.out.print("Ingrese su telefono: ");
            String telefono=obj.next();
            System.out.print("Ingrese su numero de contrato: ");
            int noContrato=obj.nextInt();
            System.out.print("�Que tipo de empleado es?\n 1.Administrativo\n2.Otro\nIngrese el numero de la opcion: ");
            int tipoEmpleado=obj.nextInt();
            ob.setTipoEmpleado(tipoEmpleado);
            System.out.print("Ingrese sus a�os de antiguedad: ");
            int a�osAntiguedad=obj.nextInt();
            ob.setA�osAntiguedad(a�osAntiguedad);
            System.out.print("Ingrese sus horas laborales mensuales: ");
            int hoLaborales=obj.nextInt();
            System.out.print("Ingrese su salario base mensual: ");
            double salarioBase=obj.nextDouble();
            ob.setSalarioBase(salarioBase);
            ob.getBono();
            ob.getIsr();
            System.out.println("REPORTE DE SALARIOS\n "
                    + "Nombre: "+nombre+" "+apellidos+
                    "\nCURP: "+curp+"   RFC: "+rfc+
                    "\nEmail: "+email+"   Telefono: "+telefono+"\n\nSu numero de contrato es: "
                    +noContrato+" Su numero de horas laborales mensuales son: "+hoLaborales+"\n"+ob.toString());
        }
    }
}
