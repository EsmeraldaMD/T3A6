
package t3a6;

/**
 *
 * @author esmer
 */
public class T3A6 {

    
    public static void main(String[] args) {
        operacion();
    }
    public static void operacion() {
                Datos datos = new Datos();
        datos.datos();
    }
}
