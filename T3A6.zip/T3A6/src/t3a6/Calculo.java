
package t3a6;

/**
 *
 * @author esmer
 */
public class Calculo {
    private int tipoEmpleado;
    private int a�osAntiguedad;
    private double salarioBase;
    private double bono;
    private double isr;

    public Calculo() {
    }

    @Override
    public String toString() {
        String resultados = "Su salario bruto es: "+salarioBase+"\nSu bono por antiguedad es de: "+bono+"\nSu retencion de ISR es de: "+isr+
                "\n\nSu salario total es de: "+(bono-isr);
        return resultados;
    }

    public Calculo(int tipoEmpleado, int a�osAntiguedad, double salarioBase, double bono, double isr) {
        this.tipoEmpleado = tipoEmpleado;
        this.a�osAntiguedad = a�osAntiguedad;
        this.salarioBase = salarioBase;
        this.bono = bono;
        this.isr = isr;
    }

    public int getTipoEmpleado() {
        return tipoEmpleado;
    }

    public void setTipoEmpleado(int tipoEmpleado) {
        this.tipoEmpleado = tipoEmpleado;
    }

    public int getA�osAntiguedad() {
        return a�osAntiguedad;
    }

    public void setA�osAntiguedad(int a�osAntiguedad) {
        this.a�osAntiguedad = a�osAntiguedad;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }
    
    public double getBono() {
    
        if(a�osAntiguedad>2 && a�osAntiguedad<6){
            bono = salarioBase +(0.03*salarioBase);
            if(tipoEmpleado==1){
            bono = bono +(0.01*salarioBase);
            }
        }else if(a�osAntiguedad>5 && a�osAntiguedad<11){
            bono = salarioBase +(0.08*salarioBase);
            if(tipoEmpleado==1){
            bono = bono +(0.04*salarioBase);
            }
        } else{
        bono=0;
        }
        return bono;
    }

    public void setBono(double bono) {
        this.bono = bono;
    }
    
    public double getIsr() {
        if(salarioBase>=0.01 && salarioBase<=318.00){
        isr= salarioBase-0.01;
        isr=isr*0.0192;
        isr=isr+0.0;
        }else if(salarioBase>=318.01 && salarioBase<=2699.40){
        isr= salarioBase-318.01;
        isr=isr*0.0640;
        isr=isr+6.15;
        }else if(salarioBase>=2699.41 && salarioBase<=4744.05){
        isr= salarioBase-2699.41;
        isr=isr*0.1088;
        isr=isr+158.55;
        }else if(salarioBase>=4744.06 && salarioBase<=5514.75){
        isr= salarioBase-4744.06;
        isr=isr*0.16;
        isr=isr+381;
        }else if(salarioBase>=5514.76 && salarioBase<=6602.70){
        isr= salarioBase-5514.76;
        isr=isr*0.1792;
        isr=isr+504.30;
        }else if(salarioBase>=6602.71 && salarioBase<=13316.70){
        isr= salarioBase-6602.72;
        isr=isr*0.2136;
        isr=isr+699.30;
        }else if(salarioBase>=13316.71 && salarioBase<=20988.90){
        isr= salarioBase-13316.71;
        isr=isr*0.2352;
        isr=isr+2133.30;
        }else if(salarioBase>=20988.91 && salarioBase<=40071.30){
        isr= salarioBase-20988.91;
        isr=isr*0.3;
        isr=isr+3937.80;
        }
        return isr;
    }

    public void setIsr(double isr) {
        this.isr = isr; 
    }
}
